﻿using App.Services;
using Biblioteca;
using Microsoft.AspNetCore.Mvc;

namespace Veiculos.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VeiculosController : ControllerBase
    {
        private readonly VeiculoService _service;

        public VeiculosController(VeiculoService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get() =>
            Ok(await _service.ListarAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var v = await _service.BuscarPorIdAsync(id);
            if (v == null) return NotFound();
            return Ok(v);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Veiculo v)
        {
            await _service.AdicionarAsync(v);
            return Created("", v);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Veiculo v)
        {
            if (await _service.AtualizarAsync(id, v))
                return Ok();
            return NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (await _service.RemoverAsync(id))
                return NoContent();
            return NotFound();
        }
    }
}
