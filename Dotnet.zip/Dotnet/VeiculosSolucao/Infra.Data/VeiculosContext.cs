﻿using Biblioteca;
using Microsoft.EntityFrameworkCore;

namespace Infra.Data
{
    public class VeiculosContext : DbContext
    {
        public VeiculosContext(DbContextOptions<VeiculosContext> options) : base(options) { }

        public DbSet<Veiculo> Veiculos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Veiculo>().HasDiscriminator<string>("Tipo")
                .HasValue<Carro>("Carro")
                .HasValue<Moto>("Moto");
        }
    }
}
