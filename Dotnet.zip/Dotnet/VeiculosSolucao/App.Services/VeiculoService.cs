﻿using Biblioteca;
using Infra.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Services
{
    public class VeiculoService
    {
        private readonly VeiculosContext _context;

        public VeiculoService(VeiculosContext context)
        {
            _context = context;
        }

        public async Task<List<Veiculo>> ListarAsync() => await _context.Veiculos.ToListAsync();

        public async Task<Veiculo?> BuscarPorIdAsync(int id) => await _context.Veiculos.FindAsync(id);

        public async Task AdicionarAsync(Veiculo veiculo)
        {
            _context.Veiculos.Add(veiculo);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> AtualizarAsync(int id, Veiculo novo)
        {
            var existente = await _context.Veiculos.FindAsync(id);
            if (existente == null) return false;

            existente.Modelo = novo.Modelo;
            existente.AnoFabricacao = novo.AnoFabricacao;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RemoverAsync(int id)
        {
            var veiculo = await _context.Veiculos.FindAsync(id);
            if (veiculo == null) return false;

            _context.Veiculos.Remove(veiculo);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
