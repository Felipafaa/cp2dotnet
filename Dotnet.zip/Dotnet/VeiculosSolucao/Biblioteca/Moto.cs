﻿
namespace Biblioteca
{
    public class Moto : Veiculo
    {
        public bool TemPartidaEletrica { get; set; }
        public bool TemBaul { get; set; }
    }
}
