﻿
namespace Biblioteca
{
    public class Carro : Veiculo
    {
        public int QuantidadePortas { get; set; }
        public bool TemArCondicionado { get; set; }
    }
}
